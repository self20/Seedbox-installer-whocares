﻿/*
 * PLUGIN _TASK
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.tskCommand		= "Ejecutando...";
 theUILang.tskCommandDone	= "Listo.";
 theUILang.tskConsole		= "Consola";
 theUILang.tskErrors		= "Diagnosticos";

thePlugins.get("_task").langLoaded();