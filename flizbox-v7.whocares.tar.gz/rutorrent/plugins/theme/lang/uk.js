﻿/*
 * PLUGIN THEME
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (pfactum@gmail.com)
 */

 theUILang.themeStandard	= "Стандартна";
 theUILang.theme		= "Палітра";

thePlugins.get("theme").langLoaded();