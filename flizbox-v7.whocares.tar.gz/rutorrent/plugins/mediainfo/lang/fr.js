﻿/*
 * PLUGIN MEDIAINFO
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.mediainfo		= "Media info";