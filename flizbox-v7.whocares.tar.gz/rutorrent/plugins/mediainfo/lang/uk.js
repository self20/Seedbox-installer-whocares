﻿/*
 * PLUGIN MEDIAINFO
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (pfactum@gmail.com)
 */

 theUILang.mediainfo		= "Інформація про файл";