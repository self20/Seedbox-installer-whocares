﻿/*
 * PLUGIN MEDIAINFO
 *
 * Vietnamese language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";