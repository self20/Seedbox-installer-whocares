﻿/*
 * PLUGIN MEDIAINFO
 *
 * Chinese Traditional language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";