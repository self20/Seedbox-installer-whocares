﻿/*
 * PLUGIN RATIO
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.ratios		= "Ratio";
 theUILang.ratio		= "Ratio";
 theUILang.mnuRatio		= "Set Ratio groep";
 theUILang.mnuRatioUnlimited	= "Geen Ratio";
 theUILang.ratioName		= "Naam";
 theUILang.minRatio		= "Min";
 theUILang.maxRatio		= "Max";
 theUILang.ratioUpload		= "UL";
 theUILang.ratioAction		= "Actie";
 theUILang.ratioStop		= "Stop";
 theUILang.ratioStopAndRemove	= "Stop & Clear groep";
 theUILang.ratioErase		= "Verwijder";
 theUILang.ratioEraseData	= "Verwijder data";
 theUILang.maxTime		= "Tijd";
 theUILang.ratioDefault 	= "Default ratio group";
 theUILang.setThrottleTo	= "Set channel to";

thePlugins.get("ratio").langLoaded();