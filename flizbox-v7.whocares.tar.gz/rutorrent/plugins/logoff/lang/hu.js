theUILang.logoff             = "Log off";
theUILang.logoffUsername     = "Username";
theUILang.logoffPassword     = "Password";
theUILang.logoffSwitch       = "Switch user";
theUILang.logoffPrompt       = "Do you want to log off or cancel this operation?";
theUILang.logoffSwitchPrompt = "Do you want to switch user, log off or cancel this operation?";
theUILang.logoffEmpty        = "<-- cannot be empty";

thePlugins.get("logoff").langLoaded();
