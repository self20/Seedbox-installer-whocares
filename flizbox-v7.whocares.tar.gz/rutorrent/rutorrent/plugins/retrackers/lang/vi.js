﻿/*
 * PLUGIN RETRACKERS
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.retrackers		= "Đổi máy theo dõi";
 theUILang.retrackersAdd	= "Add Announces";
 theUILang.retrackersDel	= "Remove Announces";
 theUILang.dontAddToPrivate	= "Don't touch private torrents";
 theUILang.addToBegin		= "Add announces to the beginning of the trackers list";

thePlugins.get("retrackers").langLoaded();