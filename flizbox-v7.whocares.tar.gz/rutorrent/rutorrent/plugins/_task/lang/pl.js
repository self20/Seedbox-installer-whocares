﻿/*
 * PLUGIN _TASK
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.tskCommand		= "Uruchomione...";
 theUILang.tskCommandDone	= "Gotowe.";
 theUILang.tskConsole		= "Konsola";
 theUILang.tskErrors		= "Diagnostyka";

thePlugins.get("_task").langLoaded();