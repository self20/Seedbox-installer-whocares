﻿/*
 * PLUGIN LoginMGR
 *
 * Chinese Traditional language file.
 *
 * Author: 
 */

 theUILang.accLogin		= "Login";
 theUILang.accPassword		= "Password";
 theUILang.accAccounts		= "Accounts";

thePlugins.get("loginmgr").langLoaded();