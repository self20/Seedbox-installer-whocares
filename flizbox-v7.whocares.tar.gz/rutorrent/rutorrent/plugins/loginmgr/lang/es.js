﻿/*
 * PLUGIN LoginMGR
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.accLogin		= "Login";
 theUILang.accPassword		= "Password";
 theUILang.accAccounts		= "Cuentas";

thePlugins.get("loginmgr").langLoaded();