﻿/*
 * PLUGIN SOURCE
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (pfactum@gmail.com)
 */

 theUILang.getSource		= "Отримати файл .torrent";
 theUILang.cantFindTorrent	= "Вихідний файл .torrent недоступний для цього завантаження.";

thePlugins.get("source").langLoaded();