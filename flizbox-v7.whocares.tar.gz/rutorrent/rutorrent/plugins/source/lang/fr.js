﻿/*
 * PLUGIN SOURCE
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.getSource		= "Télécharger le .torrent";
 theUILang.cantFindTorrent	= "Le fichier source du torrent n'a pas été trouvé.";

thePlugins.get("source").langLoaded();