﻿/*
 * PLUGIN MEDIAINFO
 *
 * Italian language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";