﻿/*
 * PLUGIN COOKIES
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.cookiesDesc = "Cookies (Format: domaine|nom1=contenu1;nom2=contenu2...)";
 theUILang.cookiesName = "Cookies";

thePlugins.get("cookies").langLoaded();