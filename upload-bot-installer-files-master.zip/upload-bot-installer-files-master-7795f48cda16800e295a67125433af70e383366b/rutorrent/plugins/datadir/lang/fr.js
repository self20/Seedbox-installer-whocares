﻿/*
 * PLUGIN DATADIR
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.DataDir		= "Enregistrer sous";
 theUILang.DataDirMove		= "Déplacer les fichiers";
 theUILang.datadirDlgCaption	= "Répertoire du torrent";
 theUILang.datadirDirNotFound	= "Plug-in 'DataDir': Répertoire invalide";
 theUILang.datadirSetDirFail	= "Plug-in 'DataDir': L'opération a échoué";
 theUILang.datadirPHPNotFound	= "Plug-in 'DataDir': rTorrent ne peut pas accéder à l'interpréteur php. Le plug-in ne fonctionnera pas.";

thePlugins.get("datadir").langLoaded();