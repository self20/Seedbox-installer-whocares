﻿/*
 * PLUGIN _TASK
 *
 * Latvian language file.
 *
 * Author: 
 */

 theUILang.tskCommand		= "Running...";
 theUILang.tskCommandDone	= "Done.";
 theUILang.tskConsole		= "Console";
 theUILang.tskErrors		= "Diagnostics";

thePlugins.get("_task").langLoaded();