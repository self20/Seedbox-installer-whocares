﻿/*
 * PLUGIN CHUNKS
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.Chunks		= "Pièces";
 theUILang.cAvail		= "Disponibilité";
 theUILang.cDownloaded		= "Téléchargé";
 theUILang.cMode		= "Mode";
 theUILang.chunksCount		= "Nombre de pièces";
 theUILang.chunkSize		= "Taile d'un pièce";
 theUILang.cLegend		= "Legende";
 theUILang.cLegendVal		= [ "4 pièces par cellule", "1 pièce par cellule" ];

thePlugins.get("chunks").langLoaded();