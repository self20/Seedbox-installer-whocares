<?php

$searchHistoryMaxCount 	= 256;	// max count of entries in download history
$HTTPTimeoutPerSite	= 5;	// in sec
